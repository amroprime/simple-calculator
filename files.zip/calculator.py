# Simple Calculator
# Takes two numbers and an operation (+, -, *, /) and prints the result.

num1 = float(input("Enter the first number: "))
operation = input("Enter the operation (+, -, *, /): ")
num2 = float(input("Enter the second number: "))

if operation == "+":
    print(num1 + num2)
elif operation == "-":
    print(num1 - num2)
elif operation == "*":
    print(num1 * num2)
elif operation == "/":
    if num2 == 0:
        print("Error: cannot divide by zero")
    else:
        print(num1 / num2)
else:
    print("try again")
