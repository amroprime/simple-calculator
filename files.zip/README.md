# Simple Calculator 🧮

A beginner-friendly command-line calculator written in Python. It takes two numbers and an operation from the user, then prints the result.

## Overview

The program asks the user for a first number, an operation (`+`, `-`, `*`, or `/`), and a second number. It then performs the chosen operation and prints the result to the console. If the operation isn't recognized, it prints `try again`.

## Features

- ➕ Addition, ➖ subtraction, ✖️ multiplication, and ➗ division
- 🔢 Supports decimal numbers (inputs are read as `float`)
- 🚫 Division-by-zero protection
- ⚠️ Friendly message for unsupported operations
- 🪶 Pure Python, no external libraries needed

## How It Works

1. The program prompts for the first number and converts it to a `float`.
2. It prompts for an operation symbol.
3. It prompts for the second number and converts it to a `float`.
4. An `if / elif / else` chain picks the matching operation and prints the result.
5. If the symbol isn't one of `+ - * /`, it prints `try again`.

## Getting Started

1. Make sure you have [Python 3](https://www.python.org/downloads/) installed.
2. Run the script:
   ```bash
   python calculator.py
   ```
3. Follow the prompts.

## Example

```
Enter the first number: 12
Enter the operation (+, -, *, /): *
Enter the second number: 4
48.0
```

## Customization Ideas

- Wrap the logic in a `while` loop so the user can do multiple calculations without restarting.
- Add more operations such as power (`**`), modulus (`%`), or square root.
- Add `try / except` around the number inputs to handle non-numeric entries.
- Turn the logic into functions (`add`, `subtract`, ...) for cleaner, reusable code.

## License

This project is open source and available under the [MIT License](LICENSE).
